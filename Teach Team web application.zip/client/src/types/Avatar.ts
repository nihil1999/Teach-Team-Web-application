export type Avatar = {
    avatarId: number
    avatarUrl: string;
  };
  